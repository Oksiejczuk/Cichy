<!DOCTYPE html> 
<html>  
<head>    
<meta charset="utf-8">    
<title>Moja strona WWW</title>  
</head>  
<body>    
<form method="get"  action="zadania.php">        
<input type="radio" name="radio1" value="opcja1">      
Opcja1      
<br>      
<input type="radio" name="radio2" value="opcja2">      
Opcja2      
<br>      
<input type="radio" name="radio3" value="opcja3">      
Opcja3      
<br>
<br>
<input type="submit">         
</form>  

    <?php
        if(isset($_GET["radio1"])) {
            echo $_GET["radio1"];
        }
        if(isset($_GET["radio2"])) {
            echo $_GET["radio2"];
        }
        if(isset($_GET["radio3"])) {
            echo $_GET["radio3"];
        }
    ?>

</body> 
</html>
