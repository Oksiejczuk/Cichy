package com.example.tinder

class MainViewModel {
}