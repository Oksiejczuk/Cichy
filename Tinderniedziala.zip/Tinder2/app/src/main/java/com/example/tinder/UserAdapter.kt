package com.example.tinder

import android.view.LayoutInflater
import  android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.tinder.databinding.DeveloperRowBinding
//12:20 minuta tego rozjebanego filmiku
class UserAdapter(private val users: List<User>,
    private val onUserClick: (User) -> Unit) : RecyclerView.Adapter<UserAdapter.MyViewHolder>() {

    inner class MyViewHolder(binding: DeveloperRowBinding) : ViewHolder(binding.root) {
        val image = binding.imageViewRow
        val name = binding.nameTv
        val technology = binding.technologyTv
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(binding = DeveloperRowBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

    }
}