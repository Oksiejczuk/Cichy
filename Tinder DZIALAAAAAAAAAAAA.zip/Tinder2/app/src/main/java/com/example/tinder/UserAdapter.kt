package com.example.tinder

import android.view.LayoutInflater
import  android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.tinder.databinding.DeveloperRowBinding

class UserAdapter(private val users: List<User>,
    private val onUserClick: (User) -> Unit
) :
    RecyclerView.Adapter<UserAdapter.MyViewHolder>() {

    inner class MyViewHolder(binding: DeveloperRowBinding) : ViewHolder(binding.root) {
        val image = binding.imageViewRow
        val name = binding.nameTv
        val technology = binding.technologyTv


        init {
            binding.root.seOnClickListener { onUserClick(users[adapterPosition])}
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(
            binding = DeveloperRowBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.image.setImageResource(users[position].image)
        holder.name.text = users[position].name
        holder.technology.text = users[position].technology
    }

    override fun getItemCount(): Int {
        return users.size
    }
}