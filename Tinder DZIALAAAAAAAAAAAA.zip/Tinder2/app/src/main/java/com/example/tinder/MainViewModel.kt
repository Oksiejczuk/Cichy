package com.example.tinder

import androidx.lifecycle.ViewModel

private val user1 = User(
    name = "pepe",
    surname = "Frog",
    technology = "Frogtend",
    birthDate = "10-05-2005",
    city = "Warsaw",
    image = R.drawable.jeden
)

private val user2 = User(
    name = "pepeusz",
    surname = "Frogstein",
    technology = "Frogtend",
    birthDate = "10-01-2005",
    city = "Breslau",
    image = R.drawable.dwa
)


private val user3 = User(
    name = "pepeulina",
    surname = "Jhonson",
    technology = "Frog resources",
    birthDate = "10-01-2000",
    city = "Berslau",
    image = R.drawable.trzy
)

private val data= listOf(user1,user2,user3)

interface Server{
    fun loadDataFromDb(): List<User>
}



class MainViewModel : ViewModel(),Server{
    private var user: User? = null

    override fun loadDataFromDb(): List<User> {
        return data
    }

    fun setUser(user: User) {
        this.user = user
    }

    fun getUser()= user
}


